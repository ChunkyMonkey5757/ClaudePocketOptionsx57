#!/bin/bash
echo "Launching PocketBotX57..."
python3 src/core/boot.py